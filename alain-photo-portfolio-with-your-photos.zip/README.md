# Alain Marley Photo Portfolio

This version of the website already includes your uploaded bird and waterfront pictures.

## Files included
- `index.html`
- `styles.css`
- `script.js`
- `assets/photos/` (your real images)

## To update your live GitHub Pages site
1. Open your repository in GitHub.
2. Upload and replace these files.
3. Make sure the `assets/photos` folder is uploaded too.
4. Wait a few minutes and refresh your website.
