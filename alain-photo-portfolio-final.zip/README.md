# Alain Marley Photo Portfolio

This final version contains only Alain's own photos. All sample/stock photographs have been removed.

The gallery is arranged in this order:
1. Bicentennial Tower
2. Canada goose portrait
3. Mallard portrait
4. Gull in flight
5. Goose and gull waterfront scene
6. Duck portrait
7. Additional flight and waterfront photographs

Upload every file and the full `assets/photos` folder to GitHub.
